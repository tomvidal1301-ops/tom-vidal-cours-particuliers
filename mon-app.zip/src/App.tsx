import React from 'react';
import { Mail, Phone, GraduationCap, Percent, BookOpen, ChevronRight } from 'lucide-react';

const App = () => {
  return (
    <div className="min-h-screen bg-white text-slate-900 font-sans">
      {/* Navigation */}
      <nav className="flex justify-between items-center py-6 px-8 max-w-6xl mx-auto">
        <div className="text-2xl font-black tracking-tight">Tom Vidal</div>
        <div className="hidden md:flex gap-8 text-sm font-bold text-slate-600">
          <a href="#parcours" className="hover:text-blue-600 transition-colors">Parcours</a>
          <a href="#services" className="hover:text-blue-600 transition-colors">Services</a>
          <a href="#tarifs" className="hover:text-blue-600 transition-colors">Simulateur Tarif</a>
        </div>
        <a href="tel:0781302497" className="bg-blue-600 text-white px-6 py-2 rounded-full font-bold text-sm hover:bg-blue-700 transition-all">
          07 81 30 24 97
        </a>
      </nav>

      {/* Hero Section */}
      <header className="px-8 py-16 md:py-24 max-w-6xl mx-auto grid md:grid-cols-2 gap-12 items-center">
        <div>
          <span className="text-blue-600 font-bold tracking-wider uppercase text-xs mb-4 block">Excellence Académique à Toulouse</span>
          <h1 className="text-5xl md:text-6xl font-black leading-tight mb-6">
            Réussir en Maths et Physique-Chimie.
          </h1>
          <p className="text-lg text-slate-600 mb-8 leading-relaxed">
            Professeur particulier spécialisé Lycée et Supérieur. Un accompagnement personnalisé pour bâtir la confiance et viser les meilleures écoles.
          </p>
          <div className="flex gap-4">
            <button className="bg-slate-900 text-white px-8 py-4 rounded-xl font-bold hover:bg-slate-800 transition-all">
              Prendre rendez-vous
            </button>
          </div>
        </div>
        <div className="relative">
          <div className="absolute inset-0 bg-blue-100 rounded-[2rem] transform rotate-3 scale-105 opacity-50"></div>
          <img 
            src="https://i.imgur.com/XKbpP0A.png" 
            alt="Tom Vidal" 
            className="relative z-10 w-full h-[500px] object-cover rounded-[2rem] shadow-2xl"
          />
        </div>
      </header>

      {/* Parcours Section */}
      <section id="parcours" className="bg-slate-50 py-24 px-8">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-bold mb-12">Mon parcours : une méthode éprouvée</h2>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              { year: "Bac 2020", place: "Lycée Raymond Naves", desc: "La base solide" },
              { year: "Prépa", place: "Lycée Pierre de Fermat", desc: "Rigueur MPSI-MP" },
              { year: "Ingénieur", place: "ENSEEIHT", desc: "Expertise technique" }
            ].map((step, i) => (
              <div key={i} className="bg-white p-8 rounded-2xl border border-slate-100 shadow-sm">
                <div className="text-blue-600 font-bold mb-2">{step.year}</div>
                <div className="font-bold text-lg mb-2">{step.place}</div>
                <div className="text-sm text-slate-500">{step.desc}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* SAP / Avantage Section */}
      <section className="py-24 px-8 max-w-6xl mx-auto grid md:grid-cols-2 gap-16 items-center">
        <div>
          <h2 className="text-3xl font-bold mb-6">Agrément SAP : 50% de crédit d'impôt</h2>
          <p className="text-slate-600 mb-8 leading-relaxed">
            Mes cours sont éligibles au service à la personne (SAP). Concrètement, l'État finance la moitié de vos cours via un crédit d'impôt de 50%.
          </p>
          <ul className="space-y-4">
            <li className="flex items-center gap-3">
              <div className="bg-blue-100 p-2 rounded-full text-blue-600"><Percent size={20}/></div>
              <span>50% de crédit d'impôt immédiat</span>
            </li>
            <li className="flex items-center gap-3">
              <div className="bg-blue-100 p-2 rounded-full text-blue-600"><BookOpen size={20}/></div>
              <span>Sans avance de frais (Avance immédiate)</span>
            </li>
          </ul>
        </div>
        <div className="bg-slate-900 text-white p-12 rounded-3xl">
          <h3 className="text-2xl font-bold mb-4">Besoin d'estimer votre budget ?</h3>
          <p className="text-slate-400 mb-8">Utilisez mon simulateur interactif pour calculer le coût réel après déduction fiscale.</p>
          <button className="flex items-center gap-2 bg-blue-500 hover:bg-blue-400 transition-colors px-6 py-3 rounded-xl font-bold">
            Accéder au simulateur <ChevronRight size={18}/>
          </button>
        </div>
      </section>

      {/* Footer simple */}
      <footer className="border-t border-slate-100 py-12 px-8 text-center text-slate-400 text-xs">
        <p className="mb-2">Tom Vidal — Micro-Entreprise — SIRET 106 318 249 00013</p>
        <p>© 2026 Tous droits réservés.</p>
      </footer>
    </div>
  );
};

export default App;